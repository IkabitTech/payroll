<div class="fabs notprint" >
  <div class="chat hidden">
    <div class="chat_header">
      <div class="chat_option">
   <!--    <div class="header_img"> -->
<!--         <img src="http://res.cloudinary.com/dqvwa7vpe/image/upload/v1496415051/avatar_ma6vug.jpg"/>
 --> 
        <div style="background: #42a5f5"></div>
<!--         </div>
 -->        <span id="chat_head"></span> <br> <span class="agent" id="agentuser"> </span> <span class="online" id='onlineuser'></span>

      </div>

    </div>


 
      <div  class="chat_conversion chat_converse chats">
        <ul style="margin:10px"></ul>
     
     
    </div>

    <div class="fab_field notprint">
      <a id="fab_send" class="fab" onclick="sendSMS()"><i class="fa fa-paper-plane-o is-visible"></i></a>
      <textarea id="chatSend" rows="20" name="chat_message" placeholder="Send a message" class="chat_field chat_message"></textarea>
    </div>
  </div>
    <a id="prime" class="fab" onclick="readSMS1()"><i class="prime fa fa-comments-o"></i></a>
</div>