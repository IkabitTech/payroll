A Pen created at CodePen.io. You can find this one at https://codepen.io/amnoral/pen/XGReKd.

 Just playing around with simple JavaScript & jqeury.